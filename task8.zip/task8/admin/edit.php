<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location:login.php");
    exit();
}
$prn=$_GET['prn'];
include 'db_connect.php';

if(isset($_POST['update'])){
    $prn = $_POST['prn'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $designation = $_POST['designation'];
    $about_me = $_POST['about_me'];
    $skills = $_POST['skills'];
    $mobile_no = $_POST['mobile_no'];
    $sql = "UPDATE student SET first_name='$first_name', last_name='$last_name', designation='$designation', about_me='$about_me', skills='$skills', mobile_no='$mobile_no'  WHERE prn='$prn'";
    $result = $conn->query($sql);
    if ($result === TRUE) {
        echo "Record updated successfully";
        header("Location:index.php");
    } else {
        echo "Error updating record: " . $conn->error;
    }
}




?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
    <style>
body {
    font-family: 'Roboto', sans-serif;
    background-color: #f4f4f4;
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin-top: 50px;
    margin-bottom: 50px;
}

.container {
    background: linear-gradient(135deg, #f8bbd0, #bbdefb, #eceff1);
    border-radius: 50%;
    margin: 50px;
    width: 50%;
    max-width: 500px;
    padding: 40px;
    border-radius: 50px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    text-align: center;
}
.header-button {
    display: flex;
    justify-content: space-between;
    margin-bottom: 30px;
}
.header-buttons a {
    text-decoration: none;
}
.header-buttons button {
    padding: 10px;
    font-size: 16px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s;
    color: white;
    background-color: black;
}
.header-buttons button:hover {
    background-color: black;
}
.container h1 {
    margin-bottom: 30px;
    color: #333;
    font-size: 28px;
    text-align: center;

}

.input-group {
    margin-bottom: 20px;
    text-align: left;
}

label {
    display: block;
    margin-bottom: 5px;
    font-weight: 500;
    color: #555;
}

input[type="text"], input[type="password"] {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-sizing: border-box;
    transition: border-color 0.3s;
}

input[type="text"]:focus, input[type="password"]:focus {
    border-color: #c2185b;
    outline: none;
}

.action-buttons {
    display: flex;
    justify-content: space-between;
    margin-bottom: 30px;
}

.action-buttons a {
    width: 48%;
}

.action-buttons button {
    background-color: #c2185b;
    color: white;
}

.action-buttons button:hover {
    background-color: #9c1a45;
}

button[type="submit"] {
    background-color: #8e24aa;
    color: white;
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s;
}

button[type="submit"]:hover {
    background-color: #6a1b9a;
}
</style>
</head>
<body>
    <div class="container">
        <div class="header-buttons">
        <div style="text-align: right;">
            <a href="index.php"><button>View Users</button></a>
            <a href="logout.php"><button>Logout</button></a>
        </div>

        <h1>Update User</h1>
        <?php
        $sql = "SELECT * FROM student WHERE prn='$prn'";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        ?>
        <form action="" method="POST">
            <div class="input-group">
                <label for="prn">PRN</label>
                <input type="text" id="prn" name="prn" readonly value="<?php echo $row['prn']; ?>">
            </div>
            <div class="input-group">
                <label for="first_name">First Name</label>
                <input type="text" id="first_name" name="first_name" required value="<?php echo $row['first_name']; ?>">
            </div>
            <div class="input-group">
                <label for="last_name">Last Name</label>
                <input type="text" id="last_name" name="last_name" required value="<?php echo $row['last_name']; ?>">
            </div>
            <div class="input-group">
                <label for="designation">Designation</label>
                <input type="text" id="designation" name="designation" required value="<?php echo $row['designation']; ?>">
            </div>
            <div class="input-group">
                <label for="about_me">About Me</label>
                <input type="text" id="about_me" name="about_me" required value="<?php echo $row['about_me']; ?>">
            </div>
            <div class="input-group">
                <label for="skill">SkillS</label>
                <input type="text" id="skill" name="skill" required value="<?php echo $row['skill']; ?>">
            </div>
            <div class="input-group">
                <label for="mobile_no">Mobile No</label>
                <input type="text" id="mobile_no" name="mobile_no" required value="<?php echo $row['mobile_no']; ?>">
            </div>
            <button type="submit" name="update">Update User</button>
        </form>
    </div>
</body>
</html>