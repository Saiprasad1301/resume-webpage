<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Users</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #121212;
            color: #e0e0e0;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 50px auto;
            overflow: hidden;
            padding: 2em;
            background: #1e1e1e;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            border-radius: 10px;
        }
        .header {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            margin-bottom: 20px;
        }
        .header button {
            background-color: #009879;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            margin-left: 10px;
        }
        .header button:hover {
            background-color: #006f5c;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            color: #e0e0e0;
        }
        table, th, td {
            border: 1px solid #333;
        }
        th, td {
            padding: 1em;
            text-align: left;
        }
        th {
            background-color: #333;
        }
        td a {
            text-decoration: none;
            color: #009879;
        }
        td a:hover {
            text-decoration: underline;
        }
        .message {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <?php
                $sql = "SELECT * FROM student";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    
                } else {
                    echo "<a href='add-details.php'><button>Add User</button></a>";
                }
            ?>
            <a href="logout.php"><button>Logout</button></a>
        </div>

        <h1 style="text-align:center;"><u>STUDENT</u></h1>

        <?php
        $sql = "SELECT * FROM student";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table>
            <tr>
                <th>PRN</th>
                <th>Name</th>
                <th>Contact Details</th>
                <th>Knowledge</th>
                <th>About Us</th>
                <th>Action</th>
            </tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                <td>".$row["prn"]."</td>
                <td>".$row["first_name"]." ".$row["last_name"]."<br>".$row["designation"]."</td>
                <td>".$row["mobile_no"]."</td>
                <td>Skills: ".$row["skill"]."<br>Experience: ".$row["experince"]."<br>Projects: ".$row["project"]."</td>
                <td>".$row["about_me"]."</td>
                <td><a href='edit.php?prn=".$row["prn"]."'>Edit</a> | <a href='delete.php?prn=".$row["prn"]."' onclick='return confirm(\"Are you sure you want to delete this record?\");'>Delete</a></td>
                </tr>";
            }
            echo "</table>";
        } else {
            echo "<div class='message'>No results found.</div>";
        }
        $conn->close();
        ?>
    </div>
</body>
</html>
