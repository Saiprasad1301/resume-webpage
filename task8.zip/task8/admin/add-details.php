<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location:login.php");
    exit();
}
$uid = $_SESSION['admin'];
include 'config.php';
if(isset($_POST['add'])){
    $prn = $_POST['prn'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $sql = "INSERT INTO resume (prn, first_name, last_name) VALUES ('$prn', '$first_name', '$last_name')";
    $result = $conn->query($sql);
    if ($result === TRUE) {
        echo "Record added successfully";
        header("Location:index.php");
    } else {
        echo "Error adding record: " . $conn->error;
    }
}






?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
            padding: 2em;
            background: #fff;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        form {
            width: 50%;
            margin: auto;
        }
        .input-group {
            margin: 1em 0;
        }
        label {
            display: block;
            font-weight: bold;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 0.5em;
        }
        button {
            padding: 0.5em 1em;
            background-color: #333;
            color: white;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <div style="text-align: right;">
            <a href="index.php"><button>View Users</button></a>
            <a href="logout.php"><button>Logout</button></a>
        </div>

        <h1>Add User</h1>
        <form action="" method="POST">
            <div class="input-group">
                <label for="prn">PRN</label>
                <input type="text" id="prn" name="prn" required>
            </div>
            <div class="input-group">
                <label for="first_name">First Name</label>
                <input type="text" id="first_name" name="first_name" required>
            </div>
            <div class="input-group">
                <label for="last_name">Last Name</label>
                <input type="text" id="last_name" name="last_name" required>
            </div>
            <button type="submit" name="add">Add User</button>
        </form>
    </div>
</body>
</html>