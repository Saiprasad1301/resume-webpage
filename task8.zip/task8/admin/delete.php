<?php
// Initialize the session
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location:login.php");
    exit();
}
$uid = $_SESSION['admin'];
include 'db_connect.php';

$sql = "delete from student";
$result = $conn->query($sql);
if ($result === TRUE) {
    echo "Record deleted successfully";
    header("Location:index.php");
} else {
    echo "Error deleting record: " . $conn->error;
}