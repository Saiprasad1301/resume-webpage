<?php
include 'config22.php';

// Prepare statement to avoid SQL injection
$stmt = $conn->prepare("SELECT * FROM student WHERE prn = ?");
$stmt->bind_param("s", $prn);
$prn = 'dypiu_2299';

// Execute the statement
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

// Close the statement
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title> Internship </title>
<link rel="stylesheet" href="style22.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
body {
  font-family: 'Arial', sans-serif;
  background-color: #e0f7fa; /* Light blue background for a clean look */
  color: #333333; /* Darker text color for better readability */
  display: flex;
  justify-content: center;
  padding: 20px;
}
.wrapper {
  width: 100%;
  max-width: 1000px;
  margin: 0 auto;
}
.container {
  margin: 20px 0;
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #003366; /* Navy color for header and footer */
  padding: 20px;
  border-radius: 8px;
  color: white;
}
.header-text {
  text-align: left;
}
.header-text h1 {
  color: #ffffff;
}
.header-text h3 {
  color: #cce0ff;
}
.header-img {
  flex-shrink: 0;
}
.header-img .img {
  width: 150px; /* Adjust the size as needed */
  height: auto;
  border-radius: 50%;
}
.footer {
  font-size: 12px;
  background-color: #003366;padding: 20px;
  border-radius: 8px;
  color: white;
  margin-top: 20px;
  text-align: center;
  color: #cce0ff;
}
.flex-container {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
}
.sidebar, .main-content, .aside {
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}
.sidebar {
  flex: 1;
  margin-right: 20px;
  background-color: #f2f2f2;
}
.main-content {
  flex: 2;
  margin-right: 20px;
  background-color: #f2f2f2;
}
.aside {
  flex: 1;
  background-color: #f2f2f2;
}
h2 {
  margin-bottom: 15px;
  color: #003366; /* Navy color for headings */
}
p {
  margin-bottom: 15px;
  line-height: 1.6;
}
.menuitem {
  padding: 8px 0;
  border-bottom: 1px solid #ccc;
}
a {
  text-decoration: none;
  color: #003366;
}
.img {
  width: 100%;
  border-radius: 8px;
}
</style>
</head>
<body>

<div class="wrapper">
  <div class="container">
    <div class="header">
      <div class="header-text">
        <h1><?php echo htmlspecialchars($row['first_name'] . " " . $row['last_name']); ?></h1>
        <h3><?php echo htmlspecialchars($row['designation']); ?></h3>
      </div>
      <div class="header-img">
        <img src="engg.jpg" class="img" alt="Profile Image">
      </div>
    </div>

    <div class="flex-container">
      <div class="sidebar">
        <h2>Skills</h2>
        <div class="menuitem"><?php echo htmlspecialchars($row['skill']); ?></div>
      </div>

      <div class="main-content">
        <h2>About Me</h2>
        <p><?php echo htmlspecialchars($row['about_me']); ?></p>
        <div id="frame">
        <input type="radio" name="frame" id="frame1" checked />
        <input type="radio" name="frame" id="frame2" />
        <input type="radio" name="frame" id="frame3" />
        <div id="slides">
            <div id="overflow">
                <div class="inner">
                    <div class="frame">
                        <img src="internship1.jpg">
                    </div>
                    <div class="frame">
                        <img src="internship2.jpg">
                    </div>
                    <div class="frame">
                        <img src="internship3.jpg">
                    </div>

                </div>
            </div>
        </div>
        <div id="controls">
            <label for="frame1"></label>
            <label for="frame2"></label>
            <label for="frame3"></label>
        </div>
        <div id="bullets">
            <label for="frame1"></label>
            <label for="frame2"></label>
            <label for="frame3"></label>
        </div>
    </div>
      </div>

      <div class="aside">
        <h2>Experience</h2>
        <p><?php echo htmlspecialchars($row['experince']); ?></p>
        <h2>Course</h2>
        <p><?php echo htmlspecialchars($row['course']); ?></p>
        <h2>Projects</h2>
        <p><?php echo htmlspecialchars($row['project']); ?></p>
      </div>
    </div>

    <div class="footer">
      Designed and Developed by <?php echo htmlspecialchars($row['first_name'] . " " . $row['last_name']); ?>
    </div>
  </div>
</div>

<script src="script.js"></script>

</body>
</html>
