 // hamne yaha pe slideIndex(variable) ko 0 se initialize kiya hai
 let slideIndex = 0;
 // yaha pe hamne slides ko select kiya hai
 const slides = document.querySelectorAll('#frame input[type="radio"]');

 // yaha pe hamne showSlide function banaya hai jisme n variable pass kiya hai
 function showSlide(n) {
     //ham yaha pe slideIndex ko n se update kar rahe hai
     slides[slideIndex].checked = false; 
     // ye line se current slide ka radio button uncheck ho jayega
     slideIndex = (n + slides.length) % slides.length;
     // ye line se next slide ka index milega
     slides[slideIndex].checked = true;
     // ye line se next slide ka radio button check ho jayega
     
 }
 // yaha pe hamne nextSlide function banaya hai 
 function nextSlide() {
     // ye line se next slide ka index milega
     showSlide(slideIndex + 1);

 }
 // yaha pe hamne setInterval function ka use kiya hai jisse nextSlide function 2 sec ke interval pe chalega
 setInterval(nextSlide, 2000); // Change slide every 2 seconds